# 04 Commitment To Environment

**Project:** RHINO_INSIDE
**Upstream:** https://github.com/mcneel/rhino.inside

Content specific to RHINO_INSIDE in category ARCHITECTURAL_DESIGN.

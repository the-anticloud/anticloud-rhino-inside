# OSINT Benchmark — RHINO_INSIDE

**Upstream:** https://github.com/mcneel/rhino.inside

Public-record information collected about upstream project:

- GitHub stars: see upstream
- License: MIT
- Last commit: check upstream
- Known CVEs: check NVD

Status: PENDING systematic collection.
